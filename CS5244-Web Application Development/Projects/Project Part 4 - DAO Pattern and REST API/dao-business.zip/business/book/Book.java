package business.book;

public class Book {

	/*
	 * TODO: Create private fields corresponding to the fields in the
	 * book table of your database. Generate a constructor that
	 * uses those fields. Generate getter methods for those fields,
	 * and generate a toString method that uses those fields.
	 */

	public Book(long bookId, String title, String author, int price, boolean isPublic, long categoryId) {
		// TODO Implement this constructor
	}

}
